/*
 * Question 1: Create a class that keeps track of the number of instances
 * created. Implement a static variable and method to accomplish it
 * 
 * 
 * class ObjCount
 * {
 * private static int count=0;
 * 
 * public ObjCount()
 * {
 * count++;
 * }
 * public static int getCount()
 * {
 * return count;
 * }
 * 
 * public static void main(String args[])
 * {
 * ObjCount obj=new ObjCount();
 * ObjCount obj2=new ObjCount();
 * ObjCount obj3=new ObjCount();
 * 
 * System.out.println(getCount());
 * }
 * }
 * 
 * Question 2: Write a program and create a constructor with parameters and
 * initialise the variable using a constructor.
 * 
 * class cal
 * {
 * private int a;
 * private int b;
 * cal(int m,int n)
 * {
 * this.a=m;
 * this.b=n;
 * }
 * void disp()
 * {
 * System.out.println(a+" "+b);
 * }
 * }
 * 
 * class Program18
 * {
 * public static void main(String args[])
 * {
 * cal obj=new cal(2,6);
 * obj.disp();
 * }
 * }
 * 
 * Question 3: Use a private keyword for a variable and use setter and getter
 * methods to initialise and print the values.
 * 
 * 
 * class main
 * {
 * private String name;
 * private int b;
 * 
 * public void setName(String name)
 * {
 * this.name=name;
 * }
 * public void setAge(int b)
 * {
 * this.b=b;
 * }
 * public String getName()
 * {
 * return name;
 * }
 * public int getAge()
 * {
 * return b;
 * }
 * }
 * class Program19
 * {
 * public static void main(String args[])
 * {
 * main obj=new main();
 * obj.setAge(18);
 * obj.setName("Pradeep");
 * 
 * String name=obj.getName();
 * System.out.println(name);
 * int age=obj.getAge();
 * System.out.println(age);
 * }
 * }
 * 
 * Question 4: Write a program to call an method without creating an object of a
 * class
 * 
 * class acc
 * {
 * static String name="Irfan";
 * static void call()
 * {
 * System.out.println(name);
 * }
 * }
 * class Program20
 * {
 * public static void main(String args[])
 * {
 * acc.call();
 * }
 * 
 * }
 * 
 * Question 5: Write a program which has static block and maintructor
 * overloading,initialise variables using maintructors and print it
 * 
 * class main
 * {
 * private String name;
 * private int age;
 * 
 * static
 * {
 * System.out.println("this is a static block");
 * }
 * public main()
 * {
 * System.out.println("Zero parametrized maintructor by programmer");
 * System.out.println(name+" "+age);
 * }
 * public main(String name, int age)
 * {
 * this.name=name;
 * this.age=age;
 * System.out.println("This is the parameterized constructor.");
 * }
 * public void disp2()
 * {
 * System.out.println(name+" "+age);
 * }
 * 
 * }
 * class Program21
 * {
 * public static void main(String args[])
 * {
 * main obj=new main();
 * main obj2=new main("Rahul",25);
 * obj2.disp2();
 * }
 * }
 */