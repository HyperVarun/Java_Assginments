/*
 * Q1: Take m and n input from the user and m * n integer inputs from user and
 * print the following:
 * number of positive numbers
 * number of negative numbers
 * number of odd numbers
 * number of even numbers
 * number of 0.
 * 
 * Soluton: import java.util.*;
 * class CountArray
 * {
 * public static void main(String args[])
 * {
 * Scanner sc = new Scanner(System.in);
 * System.out.println("Enter the row of the array:");
 * int row = sc.nextInt();
 * System.out.println("Enter the column of the array:");
 * int column = sc.nextInt();
 * int[][] array = new int[row][column];
 * for (int i = 0; i < row; i++) {
 * for (int j = 0; j < column; j++) {
 * System.out.print("Enter the element at row " + i + " and column " + j +
 * ": ");
 * array[i][j] = sc.nextInt();
 * }
 * }
 * int npn=0;
 * int nnn=0;
 * int non=0;
 * int nen=0;
 * int noo=0;
 * 
 * for(int i=0;i<arr.length;i++)
 * {
 * for(int j=0;j<arr[i].length;j++)
 * {
 * if(arr[i][j]<0)
 * {
 * nnn=nnn+1;
 * }
 * if(arr[i][j]>0)
 * {
 * npn=npn+1;
 * }
 * if(arr[i][j]%2!=0)
 * {
 * non=non+1;
 * }
 * if(arr[i][j]%2==0)
 * {
 * nen=nen+1;
 * }
 * if(arr[i][j]==0)
 * {
 * noo=noo+1;
 * }
 * }
 * }
 * System.out.println(npn);
 * System.out.println(nnn);
 * System.out.println(non);
 * System.out.println(nen);
 * System.out.println(noo);
 * }
 * }
 * 
 * Q2: write a program to print the elements above the secondary diagonal in a
 * user inputted square matrix.
 * 
 * Sol:
 * import java.util.*;
 * 
 * public class DigaonalSecArray {
 * public static void main(String[] args) {
 * 
 * Scanner sc = new Scanner(System.in);
 * System.out.println("Enter the size of the array martix:");
 * int size = sc.nextInt();
 * // System.out.println("Enter the column of the array:");
 * // int column = sc.nextInt();
 * int[][] array = new int[size][size];
 * System.out.println("Enter the elements of the matrix: ");
 * for (int i = 0; i < size; i++) {
 * for (int j = 0; j < size; j++) {
 * array[i][j] = sc.nextInt();
 * }
 * }
 * for (int i = 0; i < size; i++) {
 * for (int j = 0; j < size; j++) {
 * if (i + j < size - 1) {
 * System.out.println(array[i][j] + " ");
 * }
 * }
 * 
 * }
 * System.out.println();
 * 
 * }
 * 
 * }
 * 
 * Q3: write a program to print the elements of both the diagonals in a user
 * inputted square matrix in any order.
 * Sol: import java.util.Scanner;
 * 
 * public class DiagonalElements {
 * public static void main(String[] args) {
 * Scanner scanner = new Scanner(System.in);
 * 
 * // Input size of square matrix
 * System.out.print("Enter the size of square matrix: ");
 * int size = scanner.nextInt();
 * 
 * // Input square matrix elements
 * int[][] matrix = new int[size][size];
 * System.out.println("Enter the elements of the square matrix:");
 * for (int i = 0; i < size; i++) {
 * for (int j = 0; j < size; j++) {
 * matrix[i][j] = scanner.nextInt();
 * }
 * }
 * 
 * // Print both diagonals
 * System.out.println("Elements of the main diagonal:");
 * for (int i = 0; i < size; i++) {
 * System.out.print(matrix[i][i] + " ");
 * }
 * 
 * System.out.println("\nElements of the secondary diagonal:");
 * for (int i = 0; i < size; i++) {
 * System.out.print(matrix[i][size - i - 1] + " ");
 * }
 * 
 * scanner.close();
 * }
 * }
 * 
 * Q4: Write a program to find the largest element of a given 2D array of
 * integers.
 * Sol:
 * import java.util.Scanner;
 * 
 * public class ArrayLargestnumber {
 * public static void main(String[] args) {
 * 
 * Scanner sc = new Scanner(System.in);
 * System.out.println("Enter the size of the array:");
 * int size = sc.nextInt();
 * int[] array = new int[size];
 * for (int i = 0; i < size; i++) {
 * System.out.println("Enter element " + (i + 1) + ":");
 * array[i] = sc.nextInt();
 * }
 * int n = array.length;
 * int max = array[0];
 * for (int i = 0; i < n; i++) {
 * if (array[i] > max) {
 * max = array[i];
 * }
 * }
 * System.out.println(max);
 * }
 * }
 * Q5: Write a function which accepts a 2D array of integers and its size as
 * arguments and displays the elements of middle row and the elements of middle
 * column. Printing can be done in any order.
 * Sol: public class MiddleElements {
 * public static void main(String[] args) {
 * int[][] matrix = {
 * {1, 2, 3},
 * {4, 5, 6},
 * {7, 8, 9}
 * };
 * 
 * displayMiddleElements(matrix, 3);
 * }
 * 
 * public static void displayMiddleElements(int[][] matrix, int size) {
 * // Display middle row
 * int middleRow = size / 2;
 * System.out.println("Middle Row Elements:");
 * for (int j = 0; j < size; j++) {
 * System.out.print(matrix[middleRow][j] + " ");
 * }
 * System.out.println();
 * 
 * // Display middle column
 * int middleColumn = size / 2;
 * System.out.println("Middle Column Elements:");
 * for (int i = 0; i < size; i++) {
 * System.out.print(matrix[i][middleColumn] + " ");
 * }
 * System.out.println();
 * }
 * }
 * 
 */