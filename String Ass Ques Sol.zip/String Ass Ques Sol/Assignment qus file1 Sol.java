/*
 * Question 1: Write a java program to reverse a string without using inbuilt
 * method
 * Answer 1: class Program6
 * {
 * public static void main(String args[])
 * {
 * String str="PWSKILLS", nstr=" ";
 * char ch;
 * System.out.println(str);
 * for(int i=0;i<str.length();i++)
 * {
 * ch=str.charAt(i);
 * nstr=ch+nstr;
 * }
 * System.out.println(nstr);
 * }
 * }
 * Question 2: WAP in java to know whether the given string is palindrome
 * 
 * Answer 2:
 * import java.util.*;
 * 
 * class Program12
 * {
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the String :");
 * String str=sc.nextLine();
 * 
 * boolean isPalindrome=true;
 * 
 * for(int i=0;i<str.length()/2;i++)
 * {
 * if(str.charAt(i) != str.charAt(str.length()-i-1))
 * {
 * isPalindrome=false;
 * break;
 * }
 * }
 * 
 * if(isPalindrome)
 * {
 * System.out.println(str+ " is a palindrome");
 * }
 * else
 * {
 * System.out.println(str+ " is not a palindrome");
 * }
 * }
 * 
 * Question 3: Write a java program to convert upper case to lower case and vice
 * versa.
 * Answer 3:
 * 
 * class Program9
 * {
 * public static void main(String args[])
 * {
 * //StringBuilder str=new StringBuilder("PW SKILLS JAVA");
 * //StringBuilder str2=new StringBuilder("pws skills java");
 * String str="PW SKILLS JAVA";
 * String str2="pws skills java";
 * System.out.println("First String " +str);
 * System.out.println("Output String "+str.toLowerCase());
 * System.out.println("Second String " +str2);
 * System.out.println("Output String "+str2.toUpperCase());
 * 
 * }
 * }
 * 
 * Question 4 : Write a java program to remove a particular character from a
 * String.
 * Answer 4:
 * 
 * import java.util.*;
 * class Program10
 * {
 * public static String RemoveCharacter(String str, char ch)
 * {
 * char[] charArray=str.toCharArray();
 * StringBuilder sb=new StringBuilder();
 * for(char c: charArray)
 * {
 * if(c!=ch)
 * {
 * sb.append(c);
 * }
 * }
 * return sb.toString();
 * }
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the string");
 * String str=sc.nextLine();
 * 
 * System.out.println("Enter the character you want to remove");
 * char ch=sc.next().charAt(0);
 * 
 * String resultString=RemoveCharacter(str,ch);
 * 
 * System.out.println("String after removing "+ch+ ":" +resultString);
 * }
 * }
 * 
 * Question 5: WAP in java to find the index value of substring
 * Answer 5:
 * import java.util.*;
 * 
 * class Program11
 * {
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the String :");
 * String str=sc.nextLine();
 * 
 * System.out.println("Enter the substring :");
 * String sub=sc.nextLine();
 * 
 * int index=str.indexOf(sub);
 * 
 * if(index==-1)
 * {
 * System.out.println("The substring is not found");
 * }
 * else
 * {
 * System.out.println("The index of the substring : " +index);
 * }
 * 
 * }
 * }
 * 
 * 
 * 
 */