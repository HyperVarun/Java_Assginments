/*
 * Question 1: What is mutable String in java explain with an example
 * Answer 1: In Java, strings are immutable by default, meaning once a string
 * object is created, its value cannot be changed. However, there are mutable
 * alternatives to strings, such as StringBuilder and StringBuffer.
 * StringBuilder and StringBuffer are mutable string classes in Java that allow
 * for efficient manipulation of strings without creating new objects every time
 * the string is modified.
 * Example :public class MutableStringExample
 * {
 * public static void main(String[] args)
 * {
 * StringBuilder mutableString = new StringBuilder("Hello");
 * System.out.println("Original String: " + mutableString);
 * 
 * // Appending to the string
 * mutableString.append(" World");
 * System.out.println("After Appending: " + mutableString);
 * 
 * // Deleting from the string
 * mutableString.delete(5, 11);
 * System.out.println("After Deleting: " + mutableString);
 * 
 * // Modifying at specific index
 * mutableString.setCharAt(0, 'h');
 * System.out.println("After Modifying: " + mutableString);
 * }
 * }
 * Question 2: WAP to reserve a String
 * Input : PWSKILLS
 * Output : SLLIKPW
 * 
 * Answer 2:
 * class Reverse
 * {
 * public static void main(String args[])
 * {
 * String str="PWSKILLS", nstr=" ";
 * char ch;
 * System.out.println(str);
 * for(int i=0;i<str.length();i++)
 * {
 * ch=str.charAt(i);
 * nstr=ch+nstr;
 * }
 * System.out.println(nstr);
 * 
 * StringBuilder str = new StringBuilder("PWSKILLS");
 * System.out.println(str);
 * 
 * System.out.println(str.reverse());
 * 
 * }
 * }
 * Question 3: WAP to resvere a sentence while preserving the position
 * Answer 3:
 * class Reverse2
 * {
 * public static void main(String args[])
 * {
 * String str="think twice", nstr=" ", mstr=" ";
 * char ch;
 * System.out.println(str);
 * for(int i=0;i<str.length()/2;i++)
 * {
 * ch=str.charAt(i);
 * nstr=ch+nstr;
 * }
 * System.out.print(nstr);
 * for(int j=str.length()/2;j<str.length();j++)
 * {
 * ch=str.charAt(j);
 * mstr=ch+mstr;
 * }
 * System.out.print(mstr);
 * 
 * 
 * }
 * }
 * 
 * Question 4 : WAP to sort a string Alphabetically
 * Answer 4:
 * import java.util.*;
 * class Sortstring
 * {
 * public static String sortString(String str)
 * {
 * char tempArray[]=str.toCharArray();
 * Arrays.sort(tempArray);
 * return new String(tempArray);
 * }
 * public static void main(String args[])
 * {
 * String str="PW Skills Java";
 * String outputString= sortString(str);
 * 
 * System.out.println("Input String " +str);
 * 
 * System.out.println("Output String" +outputString);
 * 
 * 
 * }
 * }
 */