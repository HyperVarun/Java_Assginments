/*
 * Question 1://Write a simple string program to take input from user
 * Answer 1:
 * import java.util.*;
 * 
 * class Program13
 * {
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the String :");
 * String str=sc.nextLine();
 * 
 * System.out.println(str);
 * }
 * }
 * Question 2: How do you concatenate two string in java ? give an example
 * Answer 2: Concatenation is a process of combing two or more string into a
 * single string. this can be done in multiple ways, indcuding using the +
 * operator or the concat()method
 * example:
 * 1. Using '+' operator
 * String str="Hello";
 * String str2="World";
 * System.out.println(str+" "+str2);
 * 2. Using concat() method
 * String str="Hello";
 * String str2="World";
 * System.out.println(str.concat("").concat(str2));
 * Question 3: How do you find the length of the string in java explain an
 * example
 * Answer 3: The Java String class length() method finds the length of a string.
 * The length of the Java string is the same as the Unicode code units of the
 * string.Length of characters. In other words, the total number of characters
 * present in the string.
 * example:
 * public class LengthExample{
 * public static void main(String args[]){
 * String s1="javatpoint";
 * String s2="python";
 * System.out.println("string length is: "+s1.length());
 * System.out.println("string length is: "+s2.length());
 * }}
 * Question 4 : How do you compare two strings in java? Giva an example
 * Answer 4:The Java String class compareTo() method compares the given string
 * with the current string lexicographically. It returns a positive number,
 * negative number, or 0.
 * 
 * It compares strings on the basis of the Unicode value of each character in
 * the strings.
 * 
 * If the first string is lexicographically greater than the second string, it
 * returns a positive number (difference of character value). If the first
 * string is less than the second string lexicographically, it returns a
 * negative number, and if the first string is lexicographically equal to the
 * second string, it returns 0.
 * 
 * if s1 > s2, it returns positive number
 * if s1 < s2, it returns negative number
 * if s1 == s2, it returns 0
 * 
 * Example :
 * public class CompareToExample{
 * public static void main(String args[]){
 * String s1="hello";
 * String s2="hello";
 * String s3="meklo";
 * String s4="hemlo";
 * String s5="flag";
 * System.out.println(s1.compareTo(s2));
 * System.out.println(s1.compareTo(s3));
 * System.out.println(s1.compareTo(s4));
 * System.out.println(s1.compareTo(s5));
 * }}
 * 
 * 
 * Question 5: write a program to find the length of the string"refrigerator"
 * Answer 5: class Program14
 * {
 * public static void main(String args[])
 * {
 * String str="refrigerator";
 * System.out.println("The length of this is : " +str.length());
 * }
 * }
 * Question 6: Write a program to check if the letter 'e' is present in the word
 * "Umberlla"
 * Answer 6: import java.util.*;
 * 
 * class Program15
 * {
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the String :");
 * String str=sc.nextLine();
 * boolean isEPresent=false;
 * 
 * for(int i=0;i<str.length();i++)
 * {
 * if(str.charAt(i)=='e')
 * {
 * isEPresent=true;
 * break;
 * }
 * }
 * if(isEPresent)
 * {
 * System.out.println("The letter e is present in the String");
 * }
 * else
 * {
 * System.out.println("The letter e is not present in the String");
 * }
 * }
 * }
 * Question 7: Write a program to delete all consonants from the string
 * "Hello, have a good day"
 * Answer 7: import java.util.*;
 * 
 * class Program16
 * {
 * public static void main(String args[])
 * {
 * Scanner sc=new Scanner(System.in);
 * System.out.println("Enter the String :");
 * String str=sc.nextLine();
 * System.out.println(str.replaceAll("[BCDFGHJKLMNPQRSTVXZbcdfghjklmnpqrstvxz]",
 * ""));
 * 
 * }
 * }
 */